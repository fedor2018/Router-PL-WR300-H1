#!/bin/sh

l2tp_pt=`nvram_get 2860 l2tpPassThru`
pptp_pt=`nvram_get 2860 pptpPassThru`
ipsec_pt=`nvram_get 2860 ipsecPassThru`
wan_mode=`nvram_get 2860 wanConnectionMode`
wan3gmodel=`nvram_get 2860 wan3gmodel`

if [ "$wan_mode" = "PPPOE" -o "$wan_mode" = "PPTP"  -o "$wan_mode" = "L2TP" -o "$wanmode" = "3G" ]; then
  if [ "$wanmode" = "3G" -a "$wan3gmodel" = "ME3760" ]; then
	  wan_iface="usb0"
	elif [ "$wanmode" = "3G" -a "$wan3gmodel" = "R1530" ]; then
		wan_iface="usb0"
	else
		wan_iface="ppp0"
	fi
else
	wan_iface="eth2.2"
fi

# note: they must be flush iptables
#L2TP
iptables -D FORWARD -p tcp --dport 1701 -j ACCEPT >/dev/null 2>&1
iptables -D FORWARD -p udp --dport 1701 -j ACCEPT >/dev/null 2>&1
iptables -D FORWARD -p tcp --dport 1701 -j DROP >/dev/null 2>&1
iptables -D FORWARD -p udp --dport 1701 -j DROP >/dev/null 2>&1
#PPTP
iptables -D FORWARD -p tcp --dport 1723 -j ACCEPT >/dev/null 2>&1
iptables -D FORWARD -p tcp --sport 1723 -j ACCEPT >/dev/null 2>&1
iptables -D FORWARD -p tcp --dport 1723 -j DROP >/dev/null 2>&1
iptables -D FORWARD -p 47 -j ACCEPT >/dev/null 2>&1
iptables -D FORWARD -p 47 -j DROP >/dev/null 2>&1 

iptables -D FORWARD -p udp --dport 500 -i $wan_iface -o br0 -j ACCEPT >/dev/null 2>&1
iptables -D FORWARD -p udp --dport 500 -j DROP >/dev/null 2>&1

iptables -D FORWARD -p icmp -j ACCEPT >/dev/null 2>&1
iptables -D FORWARD -i $wan_iface -j ACCEPT >/dev/null 2>&1
#IPSEC
iptables -D FORWARD -p 50 -j ACCEPT  >/dev/null 2>&1
iptables -D FORWARD -p 51 -j ACCEPT >/dev/null 2>&1
iptables -D FORWARD -p 108 -j ACCEPT >/dev/null 2>&1
iptables -D FORWARD -p udp --sport 500 --dport 500 -j ACCEPT >/dev/null 2>&1
iptables -D FORWARD -p udp --sport 4500 --dport 4500 -j ACCEPT >/dev/null 2>&1
	
iptables -D FORWARD -p 50 -j DROP >/dev/null 2>&1
iptables -D FORWARD -p 51 -j DROP >/dev/null 2>&1
iptables -D FORWARD -p 108 -j DROP >/dev/null 2>&1
iptables -D FORWARD -p udp --sport 500 --dport 500 -j DROP >/dev/null 2>&1
iptables -D FORWARD -p udp --sport 4500 --dport 4500 -j DROP >/dev/null 2>&1
# note: they exec
if [ "$ipsec_pt" = "1" ]; then	
	iptables -A FORWARD -p 50 -j ACCEPT
	iptables -A FORWARD -p 51 -j ACCEPT
	iptables -A FORWARD -p 108 -j ACCEPT
	iptables -A FORWARD -p udp --sport 500 --dport 500 -j ACCEPT
	iptables -A FORWARD -p udp --sport 4500 --dport 4500 -j ACCEPT
#	iptables -A FORWARD -p udp --dport 500 -i $wan_iface -o br0 -j ACCEPT
else
	iptables -A FORWARD -p 50 -j DROP
	iptables -A FORWARD -p 51 -j DROP
	iptables -A FORWARD -p 108 -j DROP
	iptables -A FORWARD -p udp --sport 500 --dport 500 -j DROP
	iptables -A FORWARD -p udp --sport 4500 --dport 4500 -j DROP
#	iptables -A FORWARD -p udp --dport 500 -j DROP
fi

if [ "$pptp_pt" = "1" ]; then	
	iptables -A FORWARD -p 47 -j ACCEPT
	iptables -A FORWARD -p tcp --dport 1723 -j ACCEPT
	iptables -A FORWARD -p tcp --sport 1723 -j ACCEPT
else
	iptables -A FORWARD -p 47 -j DROP
	iptables -A FORWARD -p tcp --dport 1723 -j DROP
fi

if [ "$l2tp_pt" = "1" ]; then	
	iptables -A FORWARD -p tcp --dport 1701 -j ACCEPT
	iptables -A FORWARD -p udp --dport 1701 -j ACCEPT
else
	iptables -A FORWARD -p tcp --dport 1701 -j DROP
	iptables -A FORWARD -p udp --dport 1701 -j DROP
fi

if [ "$l2tp_pt" = "1" -o "$pptp_pt" = "1" ]; then	
	iptables -A FORWARD -p icmp -j ACCEPT
	iptables -A FORWARD -i $wan_iface -j ACCEPT
fi

