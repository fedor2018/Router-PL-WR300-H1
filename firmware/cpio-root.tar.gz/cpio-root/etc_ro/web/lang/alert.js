var langType;
function msg(key)
{
	try {
		if(langType.match(/!ERR/mg)||langType.match(/^en$/mg)){
			return key;
		}
		else{
			eval("var m=_msgTable_"+langType+"[key];")
			if (!m){
				return key;
			}
			return m;
		}
	}
	catch (e) {
		return key;
	}
}

function dw(key){return document.write(key);}

////////////////////////////////////////
_msgTable_cn = {
"The maximum entry count is 2.":
	"最多允许增加2个AP！",
"The maximum entry count is 4.":
	"最多允许增加4个WDS AP！",
"The maximum entry count is 10.":
	"最多允许增加10条规则！",
"The maximum entry count is 20.":
	"最多允许增加20条规则！",
"Please select the rule to be deleted!":
	"请选择要删除的规则！",
"You fill in the values or entries already exists.":
	"您填写的值或条目已经存在了！",
	
"Please specify a firmware file.":
	"请选择一个软件升级文件！",
"Please specify a uboot file.":
	"请选择一个uboot文件！",
"Please select a config file.":
	"请选择一个配置文件！",
"Invalid file format, please try again.":
	"无效的文件格式，请重新选择！",
"Sorry, update uboot failed.":
	"更新uboot文件失败！",
"Sorry, upgrade firmware failed.":
	"升级失败！",
"Uploading firmware. Please wait...":
	"正在上传升级软件，请等待...",
"Rebootting system ...":
	"正在重启系统！",
"Load factory default ...":
	"正在恢复出厂设置！",
"Is set up and effective configuration.":
	"正在保存配置并生效！",
"Do you really want to reboot system?":
	"您确定要重启系统？",
"Do you really want to reset the current settings to default?":
	"恢复出厂设置将丢失现有的配置，您确定要恢复吗？",
"You have changed the new LAN IP address, please login using the new IP address.":
	"您已更改了新的LAN的IP地址，请使用新的IP地址登录！",
	
" can not be empty.":
	"不能为空！",
" can not be empty. and must be a valid number.":
	"不能为空，并且必须是数字。",
" can not contain spaces or special characters.":
	"不能包括空格或其它特殊字符！",
" can not be empty or include the space character!":
	"并且不能为空或包括空格符！！",
" can only contain special character: !@#^&*()_+-={}[]|:.? and blank":
	"不能包含单引号、双引号、斜杠、反斜杠、分号、逗号及空格符！",
" can only contain special character: !@#^&*()_+-={}[]|:.?":
	"不能包含单引号、双引号、斜杠、反斜杠、分号、逗号！",
" contains an invalid special characters, e.g. ( \',\",\/,\\,\%,\$,\<,\>,\;,\,) and space key.":
	"只允许包含英文，数字，以及特殊字符!@#^&*()+_-={}[]|:.,?",
" contains an invalid special characters, and the front and rear ends can not contain spaces, if included, it will automatically be removed.":
	"包含了无效的特殊字符！",
" can not include full-width characters.":
	"不能包含中文字符。",
" valid hexadecimal characters.":
	"位十六进制编码字符！",
" must be ":
	"必须是合法的",
" must be an alphabet or a number.":
	"必须是字母或数字！",
" must be a valid hexadecimal characters.":
	"必须是合法的十六进制编码字符！",
	
"The user name can't be empty, Please try it again.":
	"用户名不能为空，请重试！",
"The password can't be empty, Please try it again.":
	"密码不能为空，请重试！",
"The user name and password cannot be empty.":
	"用户名和密码不能为空！",
"The user name is wrong.":
	"用户名错误！",
"The password is wrong.":
	"密码错误！",
"The old password you entered is incorrect, Please re-enter.":
	"您输入的旧密码不正确，请重新输入！",
"Password mismatched.":
	"两次密码不匹配！",
"Exceed the maximum number of user login.":
	"超过最大用户登录数！",
	
"No set WAN IP address.":
	"您没有设置WAN的IP地址！",
"The IP address can not be the same as the current LAN IP address.":
	"您填写的IP地址不能与当前LAN的IP地址相同！",
"Invalid IP address! It should be located in the same subnet of current IP address!":
	"您填写的IP地址无效！它必须与当前IP地址在同一子网内！",
"Invalid IP address range! Ending address should be greater than or equal to the starting address!":
	"您填写的IP地址范围无效！结束地址必须大于或等于起始地址！",
"Invalid IP address range! The starting address or ending address can not be current IP address!":
	"您填写的IP地址范围无效！起始地址或结束地址不能是当前的IP地址！",
"Invalid start IP address! It should be located in the same subnet of current IP address!":
	"您填写的起始IP地址无效！它必须与当前IP地址在同一子网内！",
"Invalid end IP address! It should be located in the same subnet of current IP address!":
	"您填写的结束IP地址无效！它必须与当前IP地址在同一子网内！",
"The IP address can not be the same as the current WAN IP address.":
	"您填写的IP地址不能与当前WAN的IP地址相同！",
"Invalid DHCP client address range! The ending address should be greater than starting address!":
	"您填写的DHCP地址池范围无效！\n结束地址必须大于起始地址！",
"Invalid DHCP client address range! The starting address or ending address can not be current IP address!":
	"您填写的DHCP地址池范围无效！\n起始地址或结束地址不能是当前的IP地址！",
"Invalid gateway ISP address! It should be located in the same subnet of current IP address!":
	"您填写的网关地址无效！\n它必须与当前IP地址在同一子网内！",
"The gateway ISP address can not be the same as the current WAN IP address.":
	"您填写的网关地址不能与当前WAN的IP地址相同！",
"Invalid gateway ISP address! It should be located in the same subnet of current WAN IP address!":
	"无效的网关地址！它必须与当前WAN的IP地址在同一子网内！",
"Invalid LAN IP address, It is can not the same as the current WAN IP address, and It should be located in the same subnet of current WAN IP address.":
	"您填写的LAN口IP地址无效，它不能与当前WAN口IP地址一样，或在同一网段！",
"Invalid WAN IP address, It is can not the same as the current LAN IP address, and It should be located in the same subnet of current LAN IP address.":
	"您填写的WAN口IP地址无效，它不能与当前LAN口IP地址一样，或在同一网段！",
"The subnet mask error.":
	"您填写的子网掩码错误！",
"The IP address or Mask error.":
	"您填写的IP地址/子网掩码错误！",
"The start IP address can not greater than the end of the IP address.":
	"您填写的起始IP地址不能大于结束IP地址！",
" must be a valid MAC address, and can not be broadcast address and multicast address. e.g. (00:11:2a:f3:bb:09).":
	"必须是个合法的MAC地址，并且不允许是广播MAC地址或组播MAC地址，格式如(00:11:2a:f3:bb:09)。",
" must be a valid IP address. e.g. 192.168.100.100!":
	"必须是个合法的IP，格式如192.168.100.100！",
"The server IP address must be a valid IP address. e.g. 192.168.100.100!":
	"您填写的服务器IP地址必须是个合法的IP，格式如192.168.100.100！",
"The IP address must be a valid IP address. e.g. 192.168.100.100!":	
	"您填写的IP地址必须是个合法的IP，格式如192.168.100.100！",
"The start IP address must be a valid IP address. e.g. 192.168.100.100!":	
	"您填写的起始IP地址必须是个合法的IP，格式如192.168.100.100！",
"The end IP address must be a valid IP address. e.g. 192.168.100.100!":	
	"您填写的结束IP地址必须是个合法的IP，格式如192.168.100.100！",
"The gateway ISP address must be a valid IP address. e.g. 192.168.100.100!":	
	"您填写的网关地址必须是个合法的IP，格式如192.168.100.100！",
"The primary DNS address must be a valid IP address. e.g. 192.168.100.100!":	
	"您填写的首选DNS地址必须是个合法的IP，格式如192.168.100.100！",
"The secondary DNS address must be a valid IP address. e.g. 192.168.100.100!":	
	"您填写的备选DNS地址必须是个合法的IP，格式如192.168.100.100！",
"The subnet mask can not be empty.":
	"子网掩码地址不能为空！",	
"The subnet mask must be a valid subnet mask address. e.g. 255.255.255.0!":
	"您填写的子网掩码地址必须是个合法的IP，格式如255.255.255.0！",
	
"Invalid port range! The 1st port value should be less than 2nd value!":
	"您填写的端口范围无效！起始端口值必须小于结束端口值！",
"The port can not be empty.":
	"端口号不能为空！",
"The port must be a number(1-65535).":
	"您填写的端口号必须是1-65535之间的数字！",
"The start port can not be greater than the end port.":
	"您填写的起始端口号不能大于结束端口号！",
"The remote management port must be a number(1024-65535).":
	"您填写的远程管理端口必须是1024-65535之间的数字！",
"The FTP port is already in use. Please enter a different port number!":
	"FTP端口已在使用中，请输入其它的端口号！",
	
"Confirm NTP sync time success.":
	"请先同步NTP时间！",
"Please select schedule day.":
	"请必须选择一项(周)！",
	
"Connect to the PPPoE server successfully.":
	"连接PPPoE服务器成功！",
"Connect to the PPPoE server fail.":
	"连接PPPoE服务器失败！",
"PPPoE disconnect.":
	"已断开PPPoE！",
	
"if use TKIP encryption is going to not support 11N mode and turn off WPS feature.":
	"如果您使用TKIP加密将会不支持11N模式和关闭WPS功能！",
"if disabled broadcasting of SSID is going to turn off WPS feature.":
	"如果停用SSID广播功能，将会关闭WPS功能！",
"if use WEP encryption is going to not support 11N mode and turn off WPS feature.":
	"如果使用WEP加密将会不支持11N模式和关闭WPS功能！",
"Please input WEP password.":
	"请输入WEP密码！",
"Please input 5 ASCII characters.":
	"请输入5位ASCII码字符！",
"Please input 13 ASCII characters.":
	"请输入13位ASCII码字符！",
"Please input 5 or 13 ASCII characters.":
	"请输入5或13位ASCII码字符！",
"Please input 10 hexdecimal characters.":
	"请输入10位十六进制编码（A-F/a-f/0-9）！",
"Please input 26 hexdecimal characters.":
	"请输入26位十六进制编码（A-F/a-f/0-9）！",
"Please input 10 or 26 hexdecimal characters.":
	"请输入10或26位十六进制编码（A-F/a-f/0-9）！",
"Please input 8~63 ASCII characters.":
	"请输入8-63位ASCII码字符！",
"Please input 64 hexadecimal characters.":
	"请输入64位十六进制编码（A-F/a-f/0-9）！",
"Please input 8~63 ASCII characters or 64 hexdecimal characters.":
	"请输入8-63位ASCII码字符或64位十六进制字符！",
"The WPA password length can not be less than 8.":
	"您填写的WPA密码长度不能少于8位！",
"The PIN number validation failed.":
	"PIN码验证失败！",
"Invalid PIN! The device PIN is usually 4 or 8 digits long.":
	"无效的PIN码，它必须是4或8位数字！",
"Invalid PIN! The PIN must be a valid number.":
	"无效的PIN码，它必须是数字！",
"Checksum failed! Use PIN anyway?":
	"校验失败！",
	
"The NTP server must be a valid IP or a valid URL address.":
	"NTP服务器必须是个有效的IP地址或URL地址！",
"Please first synchronize NTP time!":
	"请首先确定已同步NTP时间！",
"The time must be a number.":
	"您填写的时间值必须是数字！",
"The hour value range must be is 0-23.":
	"您填写的小时值的范围必须是0-23！",
"The minute value range must be is 0-59.":
	"您填写的分钟值的范围必须是0-59！",
"The start time can not be greater than the end time.":
	"您填写的起始时间不能大于结束时间！",
"You must choose one of the week.":
	"您必须在星期中选择一项！",
	
" must be a valid number.":
	"必须是个有效的数字！",
"The max sessions must be a number between 1-10.":
	"最大会话数必须是1-10之间的数字！",
" must be a number between 1-15.":
	"必须是1-15之间的数字！",
" must be a number between 1-300.":
	"必须是1-300之间的数字！",
"The Tx power must be a number between 1-100.":
	"必须是1-100之间的数字！",
"The data beacon rate(DTIM) must be a number between 1-255.":
	"必须是1-255之间的数字！",
"The RTS threshold must be a number between 1-2347.":
	"必须是1-2347之间的数字！",
"The beacon interval must be a number between 20-999.":
	"必须是20-999之间的数字！",
"The fragment threshold must be a number between 256-2346.":
	"必须是256-2346之间的数字！",
"The MTU must be a number between 576~1500.":
	"您填写的MTU必须是576~1500之间的数字！",
"The MTU must be a number between 546-1492.":
	"您填写的MTU必须是546-1492之间的数字！",
" must be a number between 60-86400.":
	"必须是60-86400之间的数字！",
" must be a number between 100-100000.":
	"必须是100-100000之间的数字！",
	
"Sorry, Your input the upload bandwidth sum should not exceed the total upload bandwidth.":
	"您填写的上传带宽总和不能超过总上传带宽！",
"Sorry, Your input the download bandwidth sum should not exceed the total download bandwidth.":
	"您填写的下载带宽总和不能超过总下载带宽！",
/////////////////////////////////////////////	
"The user name":
	"用户名",
"The password":
	"密码",
"The old password":
	"旧密码",
"The new password":
	"新密码",
"The confirm password":
	"确定密码",
"The domain name":
	"域名",
"The NTP server":
	"NTP服务器",
"The server IP address":
	"服务器地址",	
"The host name":
	"主机名",
"The IP address":
	"IP地址",
"The MAC address":
	"MAC地址",
"The subnet mask":
	"子网掩码",
"The gateway ISP":
	"网关地址",
"The start IP address":
	"起始IP地址",
"The end IP address":
	"结束IP地址",
"The primary DNS address":
	"首选DNS地址",
"The secondary DNS address":
	"备用DNS地址",
"The MTU":
	"MTU",
"The redial period":
	"重拨时间",
"The Dial-in numbers":
	"拨入号码",
"Static IP":
	"静态IP",
"DHCP Client":
	"动态IP",
"Auto":
	"自动",
"Disabled":
	"已禁用",
"Enabled":
	"已启用",
"Disable":
	"禁用",
"Enable":
	"启用",
"Channel":
	"信道",
"WEP-Open System":
	"WEP开放系统",
"WEP-Shared Key":
	"WEP共享密钥",
"WEP-Auto":
	"自动",	
"None":
	"不加密",
"Disconnected":
	"已断开",
"Connected":
	"已连接",
"Connection success":
	"连接成功",
"Connection fail":
	"连接失败",
"Gateway Mode":
	"路由模式",
"WISP Mode":
	"WISP模式",
"Repeater Mode":
	"中继模式",
"Bridge Mode":
	"桥模式",
"The SSID":
	"SSID",
"The PIN number":
	"WPS PIN码",
"The beacon interval":
	"信标间隔",
"The data beacon rate(DTIM)":
	"数据标率(DTIM)",
"The fragment threshold":
	"分片域值",
"The RTS threshold":
	"RTS域值",
"The Tx power":
	"发射功率",
"WPS fail":
	"WPS失败",
"WPS success":
	"WPS成功",
"Idle":
	"空闲",
"Starting WPS...":
	"正在WPS...",
"Not used":
	"未使用",
"The URL(keyword)":
	"URL关键词",
"The comment":
	"描述",	
"The total upload bandwidth":
	"总上传带宽",	
"The total download bandwidth":
	"总下载带宽",	
"The upload bandwidth":
	"上传带宽",	
"The download bandwidth":
	"下载带宽",	
"The FTP server name":
	"FTP服务器名称",
"Uploading....":
	"正在升级...",
"Sun.":
	"星期天",
"Mon.":
	"星期一",
"Tue.":
	"星期二",
"Wed.":
	"星期三",
"Thu.":
	"星期四",
"Fri.":
	"星期五",
"Sat.":
	"星期六",
"Please wait":
	"请等待",
"seconds":
	"秒",
"Update success":
	"更新成功",
"Update fail":
	"更新失败",
"The WAN port is not connected to the network":
	"WAN口未接线缆",
"The server is not responding":
	"服务器没有回复",
"Unknown":
	"未知",
"User Name":
	"用户名",
"Password":
	"密码",
"Login":
	"登录",
"Cancel":
	"取消",
"Connect timeout!":
	"中继连接超时！",
"Connect successfully!":
	"中继连接成功！",
"Connect failed!":
	"中继连接失败！",
"Please first scanning AP!":
	"请首先扫描AP！",
"Auto scan running! please wait...":
	"自动运行站点扫描！请稍候...",
"Scan request timeout!":
	"扫描请求超时！",
"Read site-survey status failed!":
	"获取结果失败！",
"Scan timeout!":
	"扫描超时！",
"Please refresh again!":
	"请重新扫描站点！",
/////////////////////////////////////////////
"ZZZ":"ZZZ"
};

