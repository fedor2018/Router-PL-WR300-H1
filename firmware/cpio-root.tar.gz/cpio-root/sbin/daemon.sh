#!/bin/sh
#
# $Id:
#
# usage: daemon.sh
#
#scripts1

. /sbin/global.sh
wanip="0"
wanLink="0"
oldWanStatus=`nvram_get 2860 wan_connection_status`
curWanStatus="0"
count=0
timenum=1
apCliEnable=`nvram_get 2860 ApCliEnable`
wanmode=`nvram_get 2860 wanConnectionMode`
opmode=`nvram_get 2860 OperationMode`
wan3gmodel=`nvram_get 2860 wan3gmodel`
#dns1="14.18.240.6"
dns1="114.114.114.114"
timenum=1

if [ "$CONFIG_WAN_AT_P0" == "y" ]; then
	wan_index="0"
else
	wan_index="4"
fi

if [ "$wanmode" = "3G" ];then 
	wired_wan="0"
else
	wired_wan="1"
fi

while [ "1" == "1" ]
do
	wanip=`ifconfig $wan_ppp_if 2>/dev/null |grep 'inet addr' |cut -d ":" -f2|cut -d" " -f1`
	wanLink=`mii_mgr -g -p $wan_index -r 1 |grep "d"`
	wifiEnable=`nvram_get 2860 WiFiOff`
	wan_phy_status=`nvram_get 2860 wan_phy_status`
	if [ "$opmode" == "0" -a  "$apCliEnable" == "0" ];then
		if [ "$wanip" != "" ];then
				curWanStatus="1"
			else
				curWanStatus="0"
			fi
	elif [ "$opmode" == "1" ];then
		if [ "$wired_wan" == "1" ];then
			if [ "$wanLink" != "" -a "$wanip" != "" ];then
				curWanStatus="1"
			else
				curWanStatus="0"
			fi
		else
			if [ "$wanip" != "" ];then
				curWanStatus="1"
			else
				curWanStatus="0"
			fi
		fi
	elif [ "$opmode" == "0" -a  "$apCliEnable" == "1" ];then 
		if [ "$wifiEnable" == "0" ];then
			apCliStatus=`iwpriv apcli0 stat|grep "Not-Associated"`	
			if [ "$apCliStatus" != "" ];then
				curWanStatus="0"
			else
				curWanStatus="1"
			fi
		else
			curWanStatus="0"
		fi
	elif [ "$opmode" == "3" ];then
		if [ "$wifiEnable" == "0" -a "$wanip" != "" -a "$wan_phy_status" != "0" ];then
				curWanStatus="1"
		else
			  curWanStatus="0"
		fi
	fi
	
#	echo "11---oldWanStatus====$oldWanStatus"
#	echo "11---curWanStatus====$curWanStatus"
	if [ "$curWanStatus" == "1" ];then
		if [ "$timenum" == "1" -o "$oldWanStatus" != "$curWanStatus" ];then
			nvram_set 2860 wan_connection_status 1
			config-dnsmasq.sh
			gpio l 11 4000 0 0 0 0
		fi
		timenum=2
	fi
	
	if [ "$curWanStatus" == "0" ];then
		if [ "$timenum" == "1" -o "$oldWanStatus" != "$curWanStatus" ];then
			nvram_set 2860 wan_connection_status 0
			config-dnsmasq.sh
			gpio l 11 0 1 0 0 0
		fi
		timenum=2
	fi
#	
	oldWanStatus=$curWanStatus
#	echo "22---oldWanStatus====$oldWanStatus"
#	echo "22---curWanStatus====$curWanStatus"
	# send signale 33 to goahead every 30 seconds if we found the wan connection is down when the wan mode is 3G
	if [ "$wanmode" == "3G" ];then
		if [ "$count" == "10" ];then
			if [ "$wan3gmodel" == "R1530" ];then
				dial4g=`ps | grep "dial4g" | sed /grep/d | wc -l`
				if [ "$dial4g" != "1" ];then
					ping -s 1 -c 1 $dns1
					if [ "$?" != "0" ];then
						echo "-----------ping nok!!!!-----------"
						killall udhcpc
						killall dial4g
						curWanStatus="0"
					else
						echo "-----------ping ok!!!!-----------"
						curWanStatus="1"
					fi
				fi
			fi
			if [ "$curWanStatus" == "0" ];then
				killall -33 goahead
			fi
			count=0
		fi
		count=`expr $count + 1` 
	fi
	
	sleep 3
done

