#!/bin/sh
#

opmode=`nvram_get 2860 OperationMode`
wan_mode=`nvram_get 2860 wanConnectionMode`
wan3gmodel=`nvram_get 2860 wan3gmodel`
echo "opmode="$opmode
echo "wan_mode="$wan_mode

if [ "$opmode" = "0"] || [ "$opmode" = "3"]; then
	exit
fi

if [ "$wan_mode" = "STATIC" ] || [ "$wan_mode" = "DHCP" ]; then
	WAN_IF_NAME="eth2.2"
else
	if [ "$wan_mode" = "3G" -a "$wan3gmodel" = "ME3760" ]; then
		WAN_IF_NAME="usb0"
  elif [ "$wan_mode" = "3G" -a "$wan3gmodel" = "R1530" ]; then
	  WAN_IF_NAME="usb0"
	else
		WAN_IF_NAME="ppp0"
	fi
fi

echo "WAN_IF_NAME="$WAN_IF_NAME

s1=`ifconfig $WAN_IF_NAME | grep "inet addr"`
if [ "$s1" = "" ];then
	exit
fi
wan_ip=`ifconfig $WAN_IF_NAME | grep "inet addr" | cut -f2 -d: | cut -f1 -d " "`

echo "1=" $1 "2=" $2 "3=" $3 "4=" $4 
if [ "$1" = "add" ]; then
	iptables -I PREROUTING -t nat  -p $2 --dport $3 -d $wan_ip -j DNAT --to $4
else
	iptables -D PREROUTING -t nat  -p $2 --dport $3 -d $wan_ip -j DNAT --to $4
fi



