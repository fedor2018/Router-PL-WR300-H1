#! /bin/sh
# Goahead need to know the event happened.
#sleep 5
#echo "zhujie" >/var/zhj
killall -SIGTTIN goahead
exit 0

