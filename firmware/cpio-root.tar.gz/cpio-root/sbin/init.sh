#!/bin/sh
#
# $Id: //WIFI_SOC/release/SDK_4_1_0_0/source/user/rt2880_app/scripts/init.sh
#
# usage: init.sh
#

. /sbin/config.sh
. /sbin/global.sh


echo "init.sh initialize the user application."

