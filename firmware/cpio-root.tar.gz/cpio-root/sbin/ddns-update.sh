#!/bin/sh
#
# $Id: //WIFI_SOC/release/SDK_4_1_0_0/source/user/rt2880_app/scripts/ddns-update.sh#1 $
#
# usage: ddns-update.sh
#

wanmode=`nvram_get 2860 wanConnectionMode`
ddns_enable=`nvram_get 2860 DDNSEnabled`
srv=`nvram_get 2860 DDNSProvider`
ddns=`nvram_get 2860 DDNS`
u=`nvram_get 2860 DDNSAccount`
pw=`nvram_get 2860 DDNSPassword`

killall -q yddns

if [ "$ddns_enable" = "0" ]; then
	exit 0
fi

if [ "$wanmode" = "PPPOE" ]; then
	s1=`ifconfig ppp0 | grep "inet addr"`
	if [ "$s1" = "" ]; then
		echo "ppp0 no addr, ddns exit"
		exit 0
	fi
	
	s2=`echo $s1 | cut -f2 -d:`	
	wan_ip_addr=`echo $s2 | cut -f1 -d " "`
elif [ "$wanmode" = "DHCP" -o "$wanmode" = "STATIC" ]; then
	s1=`ifconfig eth2.2 | grep "inet addr"`
	if [ "$s1" = "" ]; then
		echo "eth2.2 no addr, ddns exit"
		exit 0
	fi

	s2=`echo $s1 | cut -f2 -d:`
	wan_ip_addr=`echo $s2 | cut -f1 -d " "`
else
	wan_ip_addr=`echo 172.1.1.1`
fi

s3=`ifconfig eth2.2 | grep "HWaddr"`
wan_mac_addr=`echo $s3 | cut -c35-52`

#	echo "$0: unknown DDNS provider: $srv"
	exit 1
