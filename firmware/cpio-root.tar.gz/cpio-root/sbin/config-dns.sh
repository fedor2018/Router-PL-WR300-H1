#!/bin/sh

# $Id: //WIFI_SOC/release/SDK_4_1_0_0/source/user/rt2880_app/scripts/config-dns.sh#1 $
# usage: config-dns.sh [<dns1>] [<dns2>]

fname="/etc/resolv.conf"
fbak="/etc/resolv_conf.bak"
# in case no previous file
touch $fname

dnsMode=`nvram_get 2860 wan_dns_mode`
if [ "$dnsMode" == "1" ]; then
    pd=`nvram_get 2860 wan_primary_dns`
    sd=`nvram_get 2860 wan_secondary_dns`
else
    pd=$1
    sd=$2
fi

# backup file without nameserver part
sed -e '/nameserver/d' $fname > $fbak

# set primary and seconday DNS
if [ "$pd" != "" ]; then
  echo "nameserver $pd" > $fname
else # empty dns
  rm -f $fname
fi
if [ "$sd" != "" ]; then
  echo "nameserver $sd" >> $fname
fi
cat $fbak >> $fname
rm -f $fbak

