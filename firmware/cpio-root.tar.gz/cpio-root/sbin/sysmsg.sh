if [ $# -ne 1 ]
then
        echo "Paramater incorrect"
        exit 1
fi

errmsg="`/bin/date "+%Y-%m-%d %H:%M"` $1"

if [ "$errmsg" != "" ]
then
        echo "$errmsg"
        #/sbin/uci commit
        exit 0
fi

exit 2
