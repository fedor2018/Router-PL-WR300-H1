#!/bin/sh
                  		
file_name="/var/log/mon.log"                         

while [ "1" == "1" ]
do
	sleep 5
	udhcpd_pid=`ps -ef | grep udhcpd | grep -v grep | wc -l` 
	dhcp_enable=`nvram_get dhcpEnabled`
	telnetd_pid=`ps -ef | grep telnetd | grep -v grep | wc -l`  
	goahead_pid=`ps -ef | grep goahead | grep -v grep | wc -l`  
	nvram_daemon_pid=`ps -ef | grep nvram_daemon | grep -v grep | wc -l`  
	daemon_pid=`ps -ef | grep daemon.sh | grep -v grep | wc -l`
	usbmemory=`ps -ef | grep usbmemdrop.sh | grep -v grep | wc -l`
	if [ $goahead_pid -eq 0 ]
	then
		killall goahead 2> /dev/null 
		goahead & 										                                        
		echo "goahead:"${goahead_pid}, `date` >> $file_name     
	fi  
	if [ $telnetd_pid -eq 0 ]
	then
		killall telnetd 2> /dev/null   
		telnetd &										                                        
		echo "Telnet:"${telnetd_pid}, `date` >> $file_name     
	fi  

	if [ $nvram_daemon_pid -eq 0 ]
	then
		killall nvram_daemon 2> /dev/null 
		nvram_daemon &
		echo "Reload:"${nvram_daemon_pid}, `date` >> $file_name
	fi

	if [ $daemon_pid -eq 0 ];then
		killall daemon.sh 2> /dev/null 
		daemon.sh &
		echo "daemon:"${daemon_pid}, `date` >> $file_name
	fi

	if [ $usbmemory -eq 0 ];then
		killall usbmemdrop.sh 2> /dev/null 
		usbmemdrop.sh &
		echo "daemon:"${daemon_pid}, `date` >> $file_name
	fi

	if [ "$dhcp_enable" == "1" ]
	then
		if [ $udhcpd_pid -eq 0 ]
		then
			killall udhcpd 2> /dev/null 
			udhcpd /etc/udhcpd.conf &  										                                      
			echo "Dhcpd:"${udhcpd_pid}, `date` >> $file_name   
		fi
	fi
done
