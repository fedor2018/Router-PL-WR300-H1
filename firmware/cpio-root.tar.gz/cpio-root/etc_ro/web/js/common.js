var getElements=function(name){	return document.getElementsByName(name);}

function get_by_name(name)
{
	with(document){return getElementsByName(name);}
}

function get_by_id(id)
{
	with(document){return getElementById(id);}
}

function show_div(show,id) 
{
	if(show) get_by_id(id).style.display = "";
    else get_by_id(id).style.display = "none";
}

function show_html(id,val)
{
	get_by_id(id).innerHTML = val;
}

function resetClick()
{
	location=location; 
}

function selectAll(obj)
{
	for(var i = 0;i<obj.elements.length;i++){
		if(obj.elements[i].type == "checkbox")	
			obj.elements[i].checked = true;
	}
}

function selectUnAll(obj)
{
	for(var i = 0;i<obj.elements.length;i++){
		if(obj.elements[i].type == "checkbox" )	{
			if(!obj.elements[i].checked) 
				obj.elements[i].checked = true;
			else 
				obj.elements[i].checked = false;
		}
	}
}

function getRefToDivNest(divID,oDoc)
{
  	if( !oDoc ) { oDoc = document; }
  	if( document.layers ) {
		if( oDoc.layers[divID] ) { return oDoc.layers[divID]; } else {
		for( var x = 0, y; !y && x < oDoc.layers.length; x++ ) {
			y = getRefToDivNest(divID,oDoc.layers[x].document); }
		return y; } }
  	if( document.getElementById ) { return document.getElementById(divID); }
  	if( document.all ) { return document.all[divID]; }
  	return document[divID];
}

function progressBar(oBt,oBc,oBg,oBa,oWi,oHi,oDr)
{
  	MWJ_progBar++; this.id = 'MWJ_progBar' + MWJ_progBar; this.dir = oDr; this.width = oWi; this.height = oHi; this.amt = 0;
  	//write the bar as a layer in an ilayer in two tables giving the border
  	document.write('<span id="progress_div" style="display:none"><table border="0" cellspacing="0" cellpadding="'+oBt+'">'+
	'<tr><td bgcolor="'+oBc+'">'+
		'<table border="0" cellspacing="0" cellpadding="0"><tr><td height="'+oHi+'" width="'+oWi+'" bgcolor="'+oBg+'">' );
  	if( document.layers ) {
		document.write('<ilayer height="'+oHi+'" width="'+oWi+'"><layer bgcolor="'+oBa+'" name="MWJ_progBar'+MWJ_progBar+'"></layer></ilayer>' );
  	} 
	else {
		document.write('<div style="position:relative;top:0px;left:0px;height:'+oHi+'px;width:'+oWi+';">'+
			'<div style="position:absolute;top:0px;left:0px;height:0px;width:0;font-size:1px;background-color:'+oBa+';" id="MWJ_progBar'+MWJ_progBar+'"></div></div>' );
  	}
  	document.write('</td></tr></table></td></tr></table>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+msg("Uploading....")+'</span>\n' );
  	this.setBar = resetBar; //doing this inline causes unexpected bugs in early NS4
  	this.setCol = setColour;
}

function resetBar(a,b)
{
  	//work out the required size and use various methods to enforce it
  	this.amt = ( typeof( b ) == 'undefined' ) ? a : b ? ( this.amt + a ) : ( this.amt - a );
  	if( isNaN( this.amt ) ) { this.amt = 0; } if( this.amt > 1 ) { this.amt = 1; } if( this.amt < 0 ) { this.amt = 0; }
  	var theWidth = Math.round( this.width * ( ( this.dir % 2 ) ? this.amt : 1 ) );
	//alert(theWidth);
  	var theHeight = Math.round( this.height * ( ( this.dir % 2 ) ? 1 : this.amt ) );
  	var theDiv = getRefToDivNest( this.id ); if( !theDiv ) { window.status = 'Progress: ' + Math.round( 100 * this.amt ) + '%'; return; }
  	if( theDiv.style ) { theDiv = theDiv.style; theDiv.clip = 'rect(0px '+theWidth+'px '+theHeight+'px 0px)'; }
 	var oPix = document.childNodes ? 'px' : 0;
  	theDiv.width = theWidth + oPix; theDiv.pixelWidth = theWidth; theDiv.height = theHeight + oPix; theDiv.pixelHeight = theHeight;
  	if( theDiv.resizeTo ) { theDiv.resizeTo( theWidth, theHeight ); }
  	theDiv.left = ( ( this.dir != 3 ) ? 0 : this.width - theWidth ) + oPix; theDiv.top = ( ( this.dir != 4 ) ? 0 : this.height - theHeight ) + oPix;
}

function setColour(a)
{
  	//change all the different colour styles
  	var theDiv = getRefToDivNest( this.id ); if( theDiv.style ) { theDiv = theDiv.style; }
  	theDiv.bgColor = a; theDiv.backgroundColor = a; theDiv.background = a;
}

function openWindow(url,windowName,wide,high)
{
	if (document.all)
		var xMax = screen.width, yMax = screen.height;
	else if (document.layers)
		var xMax = window.outerWidth, yMax = window.outerHeight;
	else
	   var xMax = 640, yMax=500;
	
	var xOffset = (xMax - wide)/2;
	var yOffset = (yMax - high)/3;
	var settings='width='+wide+',height='+high+',screenX='+xOffset+',screenY='+yOffset+',top='+yOffset+',left='+xOffset+',resizable=yes,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes';
	window.open(url, windowName, settings);
}

function atoi(s,n)
{
    i=1;
    if (n!=1) {
        while (i!=n && s.length!=0){
            if (s.charAt(0)=='.') i++;
            s = s.substring(1);
        }
        if (i!=n) return -1;
    }
    for (i=0; i<s.length; i++){
        if (s.charAt(i)=='.'){ 
			s=s.substring(0, i); 
			break; 
		}
    }
    if (s.length==0) return -1;
    return parseInt(s, 10);
}

function isEmpty(s)
{
	if(s=="") return 0;
	return 1;
}

/*
function isSsid(s)
{
	var re1=/[^\x20-\x7D]/;
	var re2=/[\x22\x24\x25\x27\x2F\x3B\x3C\x3E\x5C\x60]/;
	if(re1.test(s)||re2.test(s))
		return 0;
	return 1;
}

function isString(s)
{
	var re1=/[^\x20-\x7D]/;
	var re2=/[\x20\x22\x24\x25\x27\x2F\x3B\x3C\x3E\x5C\x60]/;
	if(re1.test(s)||re2.test(s))
		return 0;
	return 1;
}

function isCommaString(s)
{
	var re1=/[^\x20-\x7D]/;
	var re2=/[\x20\x22\x24\x25\x27\x2c\x2F\x3B\x3C\x3E\x5C\x60]/;
	if(re1.test(s)||re2.test(s))
		return 0;
	return 1;
}
*/

function isSsid(s)
{
	for (var i=0; i<s.length; i++) {
		if (s.charAt(i) == '\'' || s.charAt(i) == '\"' || s.charAt(i) == '\/' || s.charAt(i) == '\\' || s.charAt(i) == ';' || s.charAt(i) == ',')
			return 0;
		else
	        continue;
	}
	return 1;
}

function isString(s)
{
	for (var i=0; i<s.length; i++) {
		if (s.charAt(i) == '\'' || s.charAt(i) == '\"' || s.charAt(i) == '\/' || s.charAt(i) == '\\' || s.charAt(i) == ' '|| s.charAt(i) == ';' || s.charAt(i) == ',')
			return 0;
		else
	        continue;
	}
	return 1;
}

function isVaildKeyMsg(s)
{
	if(/.*[\u4e00-\u9fa5]+.*$/.test(s)) return 0;
	//if(/[^\x00-\xff]/.test(s)) return 0;
	if (!isString(s)) return 0;
	return 1;
}

function isFilename(s)
{
	for (var i=0; i<s.length; i++) {
		if ((s.charAt(i) >= '0' && s.charAt(i) <= '9') || 
			(s.charAt(i) >= 'a' && s.charAt(i) <= 'z') || 
			(s.charAt(i) >= 'A' && s.charAt(i) <= 'Z') || 
			(s.charAt(i) == '_'))
			continue;		
		return 0;
	}
	return 1;
}

function isFirstZero(v)
{
	for (var i=0; i<v.length; i++) {
		if (v.length>1 && v.charAt(0)=='0')
			return 0;
	}
	return 1;
}

function isFirstEndSpace(v)
{
	var len=v.length;
	for (var i=0; i<len; i++) {
		if (len>1 && (v.charAt(0)==' ' || v.charAt(len-1)==' '))
			return 0;
	}
	return 1;
}

function strTrim(s) 
{
    return s.replace(/(^\s*)|(\s*$)/g,'');
}

function isNumber(v)
{
	if (!isFirstZero(v)) return 0;
	for (var i=0; i<v.length; i++) {
    	if (v.charAt(i) >= '0' && v.charAt(i) <= '9')
			continue;		
		return 0;
  	}
	return 1;
}

function isNumberMsg(s,m)
{
	if(!isNumber(s)) {alert(m+msg(" must be a valid number.")); return 0;}
	return 1;
}

function isNumberRange(s,min,max)
{
	if(parseInt(s)<min||parseInt(s)>max) return 0;
	return 1;
}

function isBlankMsg(s,m)
{
	if(!isEmpty(s)) {alert(m+msg(" can not be empty.")); return 0;}
	if(!isVaildKeyMsg(s)) {alert(m+msg(" can not include full-width characters.")); return 0;}
	if(!isString(s)) {alert(m+msg(" can only contain special character: !@#^&*()_+-={}[]|:.? and blank")); return 0;}
	return 1;
}

function isBlankMsg2(s,m)
{
	if(!isEmpty(s)) {alert(m+msg(" can not be empty. and must be a valid number.")); return 0;}
	if(!isNumber(s)) {alert(m+msg(" must be a valid number.")); return 0;}
	return 1;
}

function isBlankMsg3(s,m)
{
}

function isBlankMsg4(s,m)
{
}

function isBlankMsg5(s,m)
{
	if(!isEmpty(s)) {alert(m+msg(" can not be empty.")); return 0;}
	if(!isVaildKeyMsg(s)) {alert(m+msg(" can not include full-width characters.")); return 0;}
	if(!isString(s)) {alert(m+msg(" can only contain special character: !@#^&*()_+-={}[]|:.? and blank")); return 0;}
	return 1;
}

function isValidSsidMsg(s,m)
{
	if(!isEmpty(s)) {alert(m+msg(" can not be empty.")); return 0;}
	//if(!isVaildKeyMsg(s)) {alert(m+msg(" can not include full-width characters.")); return 0;}
	if(!isSsid(s)) {alert(m+msg(" can only contain special character: !@#^&*()_+-={}[]|:.?")); return 0;}
	return 1;
}

function isHex(s)
{
	for (var i=0; i<s.length; i++) {
    	if ( (s.charAt(i) >= '0' && s.charAt(i) <= '9') || (s.charAt(i) >= 'a' && s.charAt(i) <= 'f') || (s.charAt(i) >= 'A' && s.charAt(i) <= 'F'))
			continue;		
		return 0;
  	}
	return 1;
}

function isHexMsg(s,m)
{
	if(!isHex(s)){alert(m+msg(" must be a valid hexadecimal characters.")); return 0;}
	return 1;
}

function isHexMsg2(s,m,len1,len2)
{
	if(!isHex(s)||len1!=len2){alert(m+msg(" must be ")+len2+msg(" valid hexadecimal characters.")); return 0;}
	return 1;
}

function isPort(s)
{
	if(!isNumber(s)) return 0;
	if(parseInt(s)<1||parseInt(s)>65535) return 0;
	return 1;
}

function isPort2(s)
{
	if(!isNumber(s)) return 0;
	if(parseInt(s)<1024||parseInt(s)>65535) return 0;
	return 1;
}

function isPortMsg(s)
{
	if(!isEmpty(s)) {alert(msg("The port can not be empty.")); return 0;}
	if(!isPort(s)) {alert(msg("The port must be a number(1-65535).")); return 0;}
	return 1;
}

function isRemotePortMsg(s)
{
	if(!isEmpty(s)) {alert(msg("The port can not be empty.")); return 0;}
	if(!isPort2(s)) {alert(msg("The remote management port must be a number(1024-65535).")); return 0;}
	return 1;
}

function isPortRange(s1,s2)
{
	if(parseInt(s1)>parseInt(s2)) {alert(msg("The start port can not be greater than the end port.")); return 0;}
	return 1;
}

function isMac(s)
{
	if(s.length!=17) return 0;	
	for (var i=0; i<s.length; i++) {
    	if ((s.charAt(i) >= '0' && s.charAt(i) <= '9') || (s.charAt(i) >= 'a' && s.charAt(i) <= 'f') || (s.charAt(i) >= 'A' && s.charAt(i) <= 'F') || (s.charAt(i) == ':'))
			continue;	
		return 0;
  	}	
	if(s.split(":").length!=6) return 0;	
	if((s.toUpperCase()=="FF:FF:FF:FF:FF:FF")||(s.toUpperCase()=="00:00:00:00:00:00")) return 0;
	for(var k=0;k<s.length;k++){if((s.charAt(1)&0x01)||(s.charAt(1).toUpperCase()=='B')||(s.charAt(1).toUpperCase()=='D')||(s.charAt(1).toUpperCase()=='F')) return 0;}
	return 1;
}

function isMacMsg(s,m)
{
	if(!isEmpty(s)) {alert(m+msg(" can not be empty.")); return 0;}
	if(!isMac(s)) {alert(m+msg(" must be a valid MAC address, and can not be broadcast address and multicast address. e.g. (00:11:2a:f3:bb:09).")); return 0;}
	return 1;
}

function isIpCharset(s)
{
	for (var i=0; i<s.length; i++) {
    	if ((s.charAt(i) >= '0' && s.charAt(i) <= '9') || (s.charAt(i) == '.'))
			continue;		
		return 0;
  	}	
	var v=s.split(".");
	if(v.length!=4) return 0;
	return 1;
}

function ipTest(s,n,min,max)
{
	var d=atoi(s,n);
	if(d<min||d>max) return 0;
	return 1;
}

function isIpAddr(s)
{
	if(!isIpCharset(s)) return 0;
	if(!ipTest(s,1,1,255)||!ipTest(s,2,0,255)||!ipTest(s,3,0,255)||!ipTest(s,4,1,254)) return 0;
	return 1;
}

function isIpAddrMsg(s,m)
{
	if(!isEmpty(s)) {alert(m+msg(" can not be empty.")); return 0;}
	if(!isIpAddr(s)) {alert(m+msg(" must be a valid IP address. e.g. 192.168.100.100!")); return 0;}
	return 1;
}

function maskTest(s,n)
{
  	var d=atoi(s,n);
  	if(!(d==0||d==128||d==192||d==224||d==240||d==248||d==252||d==254||d==255)) return 0;
  	return 1;
}

function isMaskAddr(s)
{
	if(!isIpCharset(s)) return 0;
	if(!maskTest(s,1)||!maskTest(s,2)||!maskTest(s,3)||!maskTest(s,4)) return 0;
	return 1;
}

function isMaskAddrMsg(s)
{
	if(!isEmpty(s)) {alert(msg("The subnet mask can not be empty.")); return 0;}
	if(!isMaskAddr(s)) {alert(msg("The subnet mask must be a valid subnet mask address. e.g. 255.255.255.0!")); return 0;}
	return 1;
}

function getMaskLength(ipv4)
{
	var aIPsec=ipv4.split("."); 
	var len=0;
	for(var i=0;i<4;i++){
		aIPsec[i]=parseInt(aIPsec[i]).toString(2);
	}
	var nIPaddr=aIPsec[0].toString()+aIPsec[1].toString()+aIPsec[2].toString()+aIPsec[3].toString();
	for(i=0;i<nIPaddr.length;i++){
		if(nIPaddr.charAt(i)==1)
			len++;
	}
	return len;
}

function isIpSubnet(s1,mn,s2)
{
  	var ip1=s1.split(".");
   	var ip2=s2.split(".");
   	var ip3=mn.split(".");
   	//if(ip1.length!=4||ip2.length!=4||ip3.length!=4) return 0;
   	for(var k=0;k<=3;k++){
		if((ip1[k]&ip3[k])!=(ip2[k]&ip3[k])) return 0;
	}
   	return 1;
}

function isIpSubnet2(s1, s2)
{
  	ip1 = s1.replace(/\.\d{1,3}$/,".");
  	ip2 = s2.replace(/\.\d{1,3}$/,".");
  	if (ip1==ip2) return 0;
	return 1;
}

function isIpRange(s1,s2)
{
	var ip1=s1.split(".");
	var ip2=s2.split(".");
	//if(ip1.length!=4||ip2.length!=4) return 0;
	for(var k=0;k<4;k++){
		var a=Number(ip1[3]);
		var b=Number(ip2[3]);
      	if(a>=b) return 0;
	}
	return 1;
}

function isServerIp(s) 
{
	if (!isString(s) && !isIpAddr(s)) return 0;
	return 1;
}

function decomIP(ipa,ips,nodef)
{
	var re = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
	if (re.test(ips)){
		var d =  ips.split(".");
		for (i = 0; i < 4; i++){
			ipa[i].value=d[i];
			if (!nodef) ipa[i].defaultValue=d[i];
		}
		return true;
	}
	return false;
}

function decomIP2(ipa,ips,nodef)
{
	var re = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
	if (re.test(ips)){
		var d =  ips.split(".");
		for (i = 0; i < 3; i++){
			ipa[i].value=d[i];
			if (!nodef) ipa[i].defaultValue=d[i];
		}
		return true;
	}
	return false;
}

function decomMAC(ma,macs,nodef)
{
    var re = /^[0-9a-fA-F]{1,2}:[0-9a-fA-F]{1,2}:[0-9a-fA-F]{1,2}:[0-9a-fA-F]{1,2}:[0-9a-fA-F]{1,2}:[0-9a-fA-F]{1,2}$/;
    if (re.test(macs)||macs=='') {
		if (ma.length!=6){
			ma.value=macs;
			return true;
		}
		if (macs!='') var d=macs.split(":");
		else var d=['','','','','',''];
        for (i = 0; i < 6; i++){
            ma[i].value=d[i];
			if (!nodef) ma[i].defaultValue=d[i];
		}
        return true;
    }
    return false;
}

function combinIP(d)
{
	if (d.length!=4) return d.value;
    var ip=d[0].value+"."+d[1].value+"."+d[2].value+"."+d[3].value;
    if (ip=="...")
        ip="";
    return ip;
}

function combinMAC(m)
{
    var mac=m[0].value.toUpperCase()+":"+m[1].value.toUpperCase()+":"+m[2].value.toUpperCase()+":"+m[3].value.toUpperCase()+":"+m[4].value.toUpperCase()+":"+m[5].value.toUpperCase();
    if (mac==":::::")
        mac="";
    return mac;
}

function scheduleSyncTime(form_name)
{
	var currentTime = new Date();

	var seconds = currentTime.getSeconds();
	var minutes = currentTime.getMinutes();
	var hours = currentTime.getHours();
	var month = currentTime.getMonth() + 1;
	var day = currentTime.getDate();
	var year = currentTime.getFullYear();

	var seconds_str = " ";
	var minutes_str = " ";
	var hours_str = " ";
	var month_str = " ";
	var day_str = " ";
	var year_str = " ";

	if(seconds < 10)
		seconds_str = "0" + seconds;
	else
		seconds_str = ""+seconds;

	if(minutes < 10)
		minutes_str = "0" + minutes;
	else
		minutes_str = ""+minutes;

	if(hours < 10)
		hours_str = "0" + hours;
	else
		hours_str = ""+hours;

	if(month < 10)
		month_str = "0" + month;
	else
		month_str = ""+month;

	if(day < 10)
		day_str = "0" + day;
	else
		day_str = day;

	var tmp1 = month_str + day_str + hours_str + minutes_str + year + " ";
	var tmp2 = hours_str +":"+ minutes_str +":"+seconds_str;
	form_name.CurTime1.value = tmp1;
	form_name.CurTime2.value = tmp2;
}

function scheduleWeek(form_name)
{
	if (form_name.week_all.checked == true) {
		form_name.week_1.disabled = true;
		form_name.week_2.disabled = true;
		form_name.week_3.disabled = true;
		form_name.week_4.disabled = true;
		form_name.week_5.disabled = true;
		form_name.week_6.disabled = true;
		form_name.week_7.disabled = true;

		form_name.week_1.checked = true;
		form_name.week_2.checked = true;
		form_name.week_3.checked = true;
		form_name.week_4.checked = true;
		form_name.week_5.checked = true;
		form_name.week_6.checked = true;
		form_name.week_7.checked = true;		
	} 
	else {		
		form_name.week_1.disabled = false;
		form_name.week_2.disabled = false;
		form_name.week_3.disabled = false;
		form_name.week_4.disabled = false;
		form_name.week_5.disabled = false;
		form_name.week_6.disabled = false;
		form_name.week_7.disabled = false;

		form_name.week_1.checked = false;
		form_name.week_2.checked = false;
		form_name.week_3.checked = false;
		form_name.week_4.checked = false;
		form_name.week_5.checked = false;
		form_name.week_6.checked = false;
		form_name.week_7.checked = false;
	}
}

function scheduleTime(form_name)
{
	if (form_name.time_all.checked == true) {
		form_name.time_h1.disabled = true;
		form_name.time_h2.disabled = true;
		form_name.time_m1.disabled = true;
		form_name.time_m2.disabled = true;
	} 
	else {
		form_name.time_h1.disabled = false;
		form_name.time_h2.disabled = false;
		form_name.time_m1.disabled = false;
		form_name.time_m2.disabled = false;
	}
}

function scheduleWeekCheck(form_name)
{
	var i;
	if (form_name.week_all.checked == false){
		for(i=1;i<=7;i++){			
			if(eval("form_name.week_"+i+".checked") == true)
				return 0;
		}
		alert(msg("You must choose one of the week."));
		return 1;
	}
	return 0;
}

function scheduleTimeRangeCheck(val, flag)
{	
	var t = /[^0-9]{1,2}/;	
	if (t.test(val)){
		alert(msg("The time must be a number."));
		return 0;
	}		
	if (flag == 1)	{	//hour
		if (parseInt(val) < 0 || parseInt(val) > 23){  
			alert(msg("The hour value range must be is 0-23."));
			return 0;
		}
	}
	else {	//minute
		if (parseInt(val) < 0 || parseInt(val) > 59){  
			alert(msg("The minute value range must be is 0-59."));
			return 0;
		}
	}
	return 1;
}

function scheduleTimeCmpCheck(v1, v2, v3, v4)
{
	if(v1.length==2 && v1.charAt(0) == 0)
		v1 = v1.charAt(1);
	if(v2.length==2 && v2.charAt(0) == 0)
		v2 = v2.charAt(1);
	if(v3.length==2 && v3.charAt(0) == 0)
		v3 = v3.charAt(1);
	if(v4.length==2 && v4.charAt(0) == 0)
		v4 = v4.charAt(1);
	
	if (parseInt(v1) > parseInt(v2)){
		alert(msg("The start time can not be greater than the end time."));
		return 0;
	}

	if (parseInt(v1) == parseInt(v2)) {
		if (parseInt(v3) > parseInt(v4)){
			alert(msg("The start time can not be greater than the end time."));
			return 0;
		}
	}
	return 1;
}

function scheduleTimeCheck(form_name)
{
	if (form_name.time_all.checked == false) {
		if (!scheduleTimeRangeCheck(form_name.time_h1.value, 1)) return 1;
		if (!scheduleTimeRangeCheck(form_name.time_h2.value, 1)) return 1;
		if (!scheduleTimeRangeCheck(form_name.time_m1.value, 0)) return 1;
		if (!scheduleTimeRangeCheck(form_name.time_m2.value, 0)) return 1;
		if (!scheduleTimeCmpCheck(form_name.time_h1.value, form_name.time_h2.value, form_name.time_m1.value, form_name.time_m2.value)) return 1;
	}
	return 0;
}

function scheduleTimeRangeCheck2(form_name)
{
	if (!scheduleTimeCmpCheck(form_name.time_h1.value, form_name.time_h2.value, form_name.time_m1.value, form_name.time_m2.value)) return 1;
	return 0;
}

function scheduleShowWeek(w)
{
	var tmp="";
	var flag = 0;
	if(parseInt(w)>=254)
		tmp = msg("Mon.")+","+msg("Tue.")+","+msg("Wed.")+","+msg("Thu.")+","+msg("Fri.")+","+msg("Sat.")+","+msg("Sun.")
		//tmp = "Mon,Tue,Wed,Thu,Fri,Sat,Sun";
	else{
		if(parseInt(w) & (0x1<<1)){
			tmp=msg("Mon.");
			flag=1;
		}
		if(parseInt(w) & (0x1<<2)){
			if(flag == 1){
				tmp +=","+msg("Tue.");
			}
			else{
				tmp=msg("Tue.");
				flag=1;
			}
		}
		if(parseInt(w) & (0x1<<3)){
			if(flag == 1){
				tmp +=","+msg("Wed.");
			}
			else{
				tmp=msg("Wed.");
				flag=1;
			}
		}
		if(parseInt(w) & (0x1<<4)){
			if(flag == 1){
				tmp +=","+msg("Thu.");
			}
			else{
				tmp=msg("Thu.");
				flag=1;
			}
		}
		if(parseInt(w) & (0x1<<5)){
			if(flag == 1){
				tmp +=","+msg("Fri.");
			}
			else{
				tmp=msg("Fri.");
				flag=1;
			}
		}
		if(parseInt(w) & (0x1<<6)){
			if(flag == 1){
				tmp +=","+msg("Sat.");
			}
			else{
				tmp=msg("Sat.");
				flag=1;
			}
		}
		if(parseInt(w) & (0x1<<7)){
			if(flag == 1){
				tmp +=","+msg("Sun.");
			}
			else{
				tmp=msg("Sun.");
			}
		}
	}
	return tmp;
}

function checkIpMask(IPorMask,msg,type)
{
	var exp=/^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/;
	if(IPorMask == "" || IPorMask == null){  
		alert(msg("The subnet mask can not be empty."));
        return false;  
    } 
	var reg = IPorMask.match(exp);

	if(reg==null)
	{
		alert(msg)
		return false;
	}
	else
	{
		if(RegExp.$1 != parseInt(RegExp.$1).toString() ||
		RegExp.$2 != parseInt(RegExp.$2).toString()||
		RegExp.$3 != parseInt(RegExp.$3).toString()||
		RegExp.$4 != parseInt(RegExp.$4).toString())
		{
			alert(msg);
			return false;
		}
		if(type==1){  //1 for mask
			var part1,part2,part3,part4;
			function maskPartCheck(part){
				var maskPart=[0,128,192,224,240,248,252,254,255];
				for(var i in maskPart){
					if(part ==  maskPart[i]){
						return true;
					}
				}
				return false;
			}
			if(maskPartCheck(RegExp.$1)&&maskPartCheck(RegExp.$2)&&maskPartCheck(RegExp.$3)&&maskPartCheck(RegExp.$4)){
				if(RegExp.$1<255){
					if(RegExp.$2==0&&RegExp.$3==0&&RegExp.$4==0){
						return true;
					}else{
						alert(msg);
						return false;
					}
				}
				if(RegExp.$2<255){
					if(RegExp.$3==0&&RegExp.$4==0){
						return true;
					}else{
						alert(msg);
						return false;
					}
				}
				if(RegExp.$3<255){
					if(RegExp.$4==0){
						return true;
					}else{
						alert(msg);
						return false;
					}
				}		
			}else{
				alert(msg);
				return false;
			}
		}
		return true;
	}
}

function disableButton (button) {
  if (document.all || document.getElementById)
    button.disabled = true;
  else if (button) {
    button.oldOnClick = button.onclick;
    button.onclick = null;
    button.oldValue = button.value;
    button.value = 'DISABLED';
  }
}

function enableButton (button) {
  if (document.all || document.getElementById)
    button.disabled = false;
  else if (button) {
    button.onclick = button.oldOnClick;
    button.value = button.oldValue;
  }
}

function skip () { this.blur(); }
function disableTextField (field) {
  if (document.all || document.getElementById)
    field.disabled = true;
  else {
    field.oldOnFocus = field.onfocus;
    field.onfocus = skip;
  }
}

function enableTextField (field) {
  if (document.all || document.getElementById)
    field.disabled = false;
  else {
    field.onfocus = field.oldOnFocus;
  }
}

function disableAllButton()
{
	var forms = document.forms;
	for (var j = 0; j < forms.length; j++) {
		var selectForm = document.forms[j];
		var control = document.forms[j].elements; 
		for (var i = 0; i < control.length; i++) {
			if (control[i].type == "button" || control[i].type == "reset" || control[i].type == "submit") {
				control[i].disabled = true;
			}
		}
	}
}

function enableAllButton()
{
	var forms = document.forms;
	for (var j = 0; j < forms.length; j++) {
		var selectForm = document.forms[j];
		var control = document.forms[j].elements; 
		for (var i = 0; i < control.length; i++) {
			if (control[i].type == "button" || control[i].type == "reset" || control[i].type == "submit") {
				control[i].disabled = false;
			}
		}
	}
}
